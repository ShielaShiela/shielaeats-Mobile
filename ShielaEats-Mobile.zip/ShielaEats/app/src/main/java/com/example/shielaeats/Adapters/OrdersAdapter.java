package com.example.shielaeats.Adapters;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.shielaeats.Models.OrdersModel;
import com.example.shielaeats.R;
import com.example.shielaeats.UpdateActivity;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class OrdersAdapter extends RecyclerView.Adapter<OrdersAdapter.viewHolder>{

    ArrayList<OrdersModel> list;
    Context context;
    AlertDialog.Builder builder;
    Button buttonordernow;
    public OrdersAdapter(ArrayList<OrdersModel> list, Context context) {
        this.list = list;
        this.context = context;
    }

    @NonNull
    @Override
    public viewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.order_sample, parent, false);
        return new viewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull viewHolder holder, int position) {

        final OrdersModel model = list.get(position);

        if(model.getCs().equals("0"))
        {

            holder.delete.setEnabled(Boolean.FALSE);
            holder.edit.setEnabled(Boolean.FALSE);
//            buttonordernow = (Button) findViewById(R.id.btnAddOrderNow);
        }

        Picasso.get().load(model.getImage()).into(holder.orderImage);
        holder.soldItemName.setText(model.getName());
        holder.price.setText(model.getPrice());
        holder.orderNumber.setText(model.getQty());
        
        holder.delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, UpdateActivity.class);
                intent.putExtra("action","delete");
                intent.putExtra("image",model.getImage());
                intent.putExtra("price",model.getPrice());
                intent.putExtra("desc",model.getDescription());
                intent.putExtra("quantity",model.getQty());
                intent.putExtra("name",model.getName());
                intent.putExtra("foodid",model.getFoodid());
                intent.putExtra("customerid",model.getCustomerid());
                intent.putExtra("restaurantid", model.getRestaurantid());
                context.startActivity(intent);
            }
        });
//
        holder.edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, UpdateActivity.class);
                intent.putExtra("image",model.getImage());
                intent.putExtra("price",model.getPrice());
                intent.putExtra("desc",model.getDescription());
                intent.putExtra("quantity",model.getQty());
                intent.putExtra("name",model.getName());
                intent.putExtra("foodid",model.getFoodid());
                intent.putExtra("customerid",model.getCustomerid());
                intent.putExtra("restaurantid", model.getRestaurantid());
                intent.putExtra("action","update");
                context.startActivity(intent);
            }
        });


    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class viewHolder extends RecyclerView.ViewHolder {

        ImageView orderImage;
        TextView soldItemName, orderNumber, price;
        Button edit, delete;
        public viewHolder(@NonNull View itemView){
            super(itemView);
            orderImage = itemView.findViewById(R.id.orderImage);
            soldItemName = itemView.findViewById(R.id.orderItemName);
            orderNumber = itemView.findViewById(R.id.orderNumber);
            price = itemView.findViewById(R.id.price);
            edit = itemView.findViewById(R.id.btneditorder);
            delete =itemView.findViewById(R.id.btndeleteorder);

        }

    }

}
