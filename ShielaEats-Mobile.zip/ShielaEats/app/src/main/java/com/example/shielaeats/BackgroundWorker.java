package com.example.shielaeats;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.shielaeats.Adapters.MainAdapter;
import com.example.shielaeats.Models.MainModel;
import com.example.shielaeats.databinding.ActivityMainBinding;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;

public class BackgroundWorker extends AsyncTask<String,Void,String> {
    Context context;
    Callback cb;
    AlertDialog alertDialog;
    String DBAction = null;
    JSONObject jsonObj = null;
    //prepare item array for "A"
    JSONArray jsonArrayProducts = new JSONArray();
    String fooditem;
    ArrayList<String> fooditemslist = new ArrayList<String>();

    ArrayList<MainModel> list = new  ArrayList<>();
    ActivityMainBinding binding;
    MainAdapter adapter;
    LinearLayoutManager layoutManager;

    public BackgroundWorker(View.OnClickListener onClickListener) {
    }

    public interface Callback {

        public void sendData(ArrayList<MainModel> list);
    }
    public BackgroundWorker(Context ctx){
        context = ctx;
//        this.cb = cb;
    }

//    public BackgroundWorker (Callback cb) {
//        this.cb = cb;
//    }




    @Override
    protected String doInBackground(String... params) {
        String type = params[0];
        DBAction = type;
        String login_link ="http://140.118.115.141:80/shielaeats/mobilephp/login.php";
        String signup_url ="http://140.118.115.141:80/shielaeats/mobilephp/signup.php";
        String product_url ="http://140.118.115.141:80/shielaeats/mobilephp/getfoodproducts.php";
        String delete_url = "http://140.118.115.141:80/shielaeats/mobilephp/deleteorder.php";
        if(type.equals("login")) {
            try {
                String user_name = params[1];
                String password = params[2];

                String post_data = URLEncoder.encode("username","UTF-8")+"=" +
                        URLEncoder.encode(user_name,"UTF-8");
                post_data += "&" + URLEncoder.encode("password","UTF-8")+"=" +
                        URLEncoder.encode(password,"UTF-8");
                Log.d("Check After Data",post_data);
                URL url = new URL(login_link);
                HttpURLConnection httpURLConnection = (HttpURLConnection)url.openConnection();
                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.setDoOutput(true);
                httpURLConnection.setDoInput(true);
                try {
                    OutputStream outputStream = httpURLConnection.getOutputStream();
                    BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8"));
                    bufferedWriter.write(post_data);
                    bufferedWriter.flush();
                    bufferedWriter.close();
                    outputStream.close();
                }catch (Exception e){ e.printStackTrace();}
                InputStream inputStream = httpURLConnection.getInputStream();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream,"iso-8859-1"));
                String result="";
                String line="";
                while((line = bufferedReader.readLine())!= null) {
                    result += line;
                }
                bufferedReader.close();
                inputStream.close();
                httpURLConnection.disconnect();
                return result;
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        else if (type.equals("signup"))
        {
            try {
                String username = params[1];
                String password = params[2];
                String usertype = params[3];

                URL url = new URL(signup_url);
                HttpURLConnection httpURLConnection = (HttpURLConnection)url.openConnection();
                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.setDoOutput(true);
                httpURLConnection.setDoInput(true);
                OutputStream outputStream = httpURLConnection.getOutputStream();
                BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8"));
                String post_data = URLEncoder.encode("username","UTF-8")+"="+URLEncoder.encode(username,"UTF-8")+"&"
                        +URLEncoder.encode("password","UTF-8")+"="+URLEncoder.encode(password,"UTF-8")+"&"
                        +URLEncoder.encode("usertype","UTF-8")+"="+URLEncoder.encode(usertype,"UTF-8");
                bufferedWriter.write(post_data);
                bufferedWriter.flush();
                bufferedWriter.close();
                outputStream.close();
                InputStream inputStream = httpURLConnection.getInputStream();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream,"iso-8859-1"));
                String result="";
                String line="";
                while((line = bufferedReader.readLine())!= null) {
                    result += line;
                }
                bufferedReader.close();
                inputStream.close();
                httpURLConnection.disconnect();
                return result;
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        else if (type.equals("ProductList"))
        {
            try {
                String restoid = "5";
                URL url = new URL(product_url);
                HttpURLConnection httpURLConnection = (HttpURLConnection)url.openConnection();
                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.setDoOutput(true);
                httpURLConnection.setDoInput(true);
                OutputStream outputStream = httpURLConnection.getOutputStream();
                BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8"));
//                String post_data = URLEncoder.encode("username","UTF-8")+"="+URLEncoder.encode(username,"UTF-8")+"&"
//                        +URLEncoder.encode("password","UTF-8")+"="+URLEncoder.encode(password,"UTF-8")+"&"
//                        +URLEncoder.encode("usertype","UTF-8")+"="+URLEncoder.encode(usertype,"UTF-8");
                bufferedWriter.write(URLEncoder.encode("restoid","UTF-8")+"="+URLEncoder.encode(restoid,"UTF-8"));
                bufferedWriter.flush();
                bufferedWriter.close();
                outputStream.close();
                InputStream inputStream = httpURLConnection.getInputStream();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream,"iso-8859-1"));
                String result="";
                String line="";
                while((line = bufferedReader.readLine())!= null) {
                    Log.d("Result PHP",line);
                    result += line;


                }

                bufferedReader.close();
                inputStream.close();
                httpURLConnection.disconnect();
                return result;
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        else if(type.equals("deleteorder"))
        {
            try {
                String orderid = params[1];

                String post_data = URLEncoder.encode("orderid","UTF-8")+"=" +
                        URLEncoder.encode(orderid,"UTF-8");

                URL url = new URL(delete_url);
                HttpURLConnection httpURLConnection = (HttpURLConnection)url.openConnection();
                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.setDoOutput(true);
                httpURLConnection.setDoInput(true);
                try {
                    OutputStream outputStream = httpURLConnection.getOutputStream();
                    BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8"));
                    bufferedWriter.write(post_data);
                    bufferedWriter.flush();
                    bufferedWriter.close();
                    outputStream.close();
                }catch (Exception e){ e.printStackTrace();}
                InputStream inputStream = httpURLConnection.getInputStream();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream,"iso-8859-1"));
                String result="";
                String line="";
                while((line = bufferedReader.readLine())!= null) {
                    result += line;
                }
                bufferedReader.close();
                inputStream.close();
                httpURLConnection.disconnect();
                return result;
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }

        }
        return null;
    }

    @Override
    protected void onPreExecute() {
        alertDialog = new AlertDialog.Builder(context).create();
        alertDialog.setTitle("Login Status");
    }

    @Override
    protected void onPostExecute(String result) {
        if (result != null) {
            alertDialog.setMessage(result);
            Log.d("Result", result);
            if (DBAction.equals("login")) {
                if(result != "User not found") {
                    Toast.makeText(context,"Welcome Customer: "+result,Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(context, RestaurantActivity.class);
                    intent.putExtra("customerid", result);
                    context.startActivity(intent);
                }
            } else if (result.equals("User Added")) {
                context.startActivity(new Intent(context, LoginActivity.class));
            }
            else if (result.equals("Order Deleted"))
            {
                Log.d("Delete Result:","Deleted");
//                Toast.makeText(context,"Deleted!",Toast.LENGTH_SHORT).show();

                //context.startActivity(new Intent(context, LoginActivity.class));
            }
            else {
                alertDialog.setMessage("wala");

            }
//            alertDialog.show();
        }
    }

    @Override
    protected void onProgressUpdate(Void... values) {
        super.onProgressUpdate(values);
    }


    public String getFoods(){
        String product_link ="http://140.118.115.141:80/shielaeats/mobilephp/getfoodproducts.php";
        try {
            String restoid = "5";
            URL url = new URL(product_link);
            HttpURLConnection httpURLConnection = (HttpURLConnection)url.openConnection();
            httpURLConnection.setRequestMethod("POST");
            httpURLConnection.setDoOutput(true);
            httpURLConnection.setDoInput(true);
            OutputStream outputStream = httpURLConnection.getOutputStream();
            BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8"));
//                String post_data = URLEncoder.encode("username","UTF-8")+"="+URLEncoder.encode(username,"UTF-8")+"&"
//                        +URLEncoder.encode("password","UTF-8")+"="+URLEncoder.encode(password,"UTF-8")+"&"
//                        +URLEncoder.encode("usertype","UTF-8")+"="+URLEncoder.encode(usertype,"UTF-8");
            bufferedWriter.write(URLEncoder.encode("restoid","UTF-8")+"="+URLEncoder.encode(restoid,"UTF-8"));
            bufferedWriter.flush();
            bufferedWriter.close();
            outputStream.close();
            InputStream inputStream = httpURLConnection.getInputStream();
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream,"iso-8859-1"));
            String result="";
            String line="";
            while((line = bufferedReader.readLine())!= null) {
                Log.d("Result PHP",line);
                result += line;


            }

            bufferedReader.close();
            inputStream.close();
            httpURLConnection.disconnect();
            return result;
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;
    }
    public void insertOrder(int orderid, int customerid, int restaurantid, int foodid, int quantity ){
        try {
            String addOrderToCart_url = "http://140.118.115.141:80/shielaeats/mobilephp/addOrdertoCart.php";
            String post_data = "";
//                    URLEncoder.encode("orderid","UTF-8")+"="+URLEncoder.encode(orderid),"UTF-8")+"&"
//                    +URLEncoder.encode("customerid","UTF-8")+"="+URLEncoder.encode(customerid,"UTF-8")+"&"
//                    +URLEncoder.encode("foodid","UTF-8")+"="+URLEncoder.encode(foodid,"UTF-8");
//                    +URLEncoder.encode("quantity","UTF-8")+"="+URLEncoder.encode(quantity,"UTF-8");

            URL url = new URL(addOrderToCart_url);
            HttpURLConnection httpURLConnection = (HttpURLConnection)url.openConnection();
            httpURLConnection.setRequestMethod("POST");
            httpURLConnection.setDoOutput(true);
            httpURLConnection.setDoInput(true);
            OutputStream outputStream = httpURLConnection.getOutputStream();
            BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8"));
            bufferedWriter.write(post_data);
            bufferedWriter.flush();
            bufferedWriter.close();
            outputStream.close();
            InputStream inputStream = httpURLConnection.getInputStream();
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream,"iso-8859-1"));
            String result="";
            String line="";
            while((line = bufferedReader.readLine())!= null) {
                result += line;
            }
            bufferedReader.close();
            inputStream.close();
            httpURLConnection.disconnect();
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


    }


}
