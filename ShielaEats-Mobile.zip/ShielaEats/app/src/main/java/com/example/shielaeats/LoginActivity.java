package com.example.shielaeats;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    EditText UsernameEt, PasswordEt;
    Button login;

//    String server_url = "http://140.118.115.141/shielaeats/mobilephp/login.php";
//    AlertDialog.Builder builder;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        UsernameEt = (EditText)findViewById(R.id.editUsername);
        PasswordEt = (EditText)findViewById(R.id.editPassword);
        
    }

    public void OnLogin(View view){

        String username = UsernameEt.getText().toString();
        String password = PasswordEt.getText().toString();
        String type = "login";
        BackgroundWorker backgroundWorker = new BackgroundWorker(this);
        Log.d("Variables",username+password);
        backgroundWorker.execute(type,username,password);
        UsernameEt.getText().clear();
        PasswordEt.getText().clear();
    }

    public void OpenReg(View view)
    {
        startActivity(new Intent(this,SignupActivity.class));
    }
}
//
//UsernameEt = (EditText)findViewById(R.id.editUsername);
//        PasswordEt = (EditText)findViewById(R.id.editPassword);
//        login = (Button)findViewById(R.id.btnLogin);
//
//        builder = new AlertDialog.Builder(this);
//
//        login.setOnClickListener(new View.OnClickListener(){
//@Override
//public void onClick(View v) {
//
//final String username,password;
//        username = UsernameEt.getText().toString();
//        password = PasswordEt.getText().toString();
//
//        StringRequest stringRequest = new StringRequest(Request.Method.POST, server_url,
//        new Response.Listener<String>() {
//@Override
//public void onResponse(String response) {
//
//        builder.setTitle("Server Response");
//        builder.setMessage("Response :"+response);
//        builder.setPositiveButton("OK", new DialogInterface.OnClickListener(){
//@Override
//public void onClick(DialogInterface dialog, int which) {
//        UsernameEt.setText("");
//        PasswordEt.setText("");
//        }
//        });
//        AlertDialog alertDialog = builder.create();
//        alertDialog.show();
//        }
//        }
//        , new Response.ErrorListener() {
//@Override
//public void onErrorResponse(VolleyError error) {
//        Toast.makeText(LoginActivity.this, error.toString(), Toast.LENGTH_SHORT).show();
//        error.printStackTrace();
//        }
//        }){
//@Override
//protected Map<String, String> getParams() throws AuthFailureError {
//        Map<String,String> params = new HashMap<String,String>();
//        params.put("name",username);
//        params.put("password",password);
//
//        return params;
//        }
//        };
//
//        Singleton.getInstance(LoginActivity.this).addTorequestque(stringRequest);
//
//
//
//        }
//        });