package com.example.shielaeats;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.shielaeats.Adapters.OrdersAdapter;
import com.example.shielaeats.Models.OrdersModel;
import com.example.shielaeats.databinding.ActivityOrderBinding;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class OrderActivity extends AppCompatActivity {

    ActivityOrderBinding binding;
    OrdersAdapter adapter;
    LinearLayoutManager layoutManager;
    int TotalPrice;
    Button btnordernow;
    String customerid, restoid, orderid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityOrderBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        customerid = getIntent().getStringExtra("customerid");
//        restoid = getIntent().getStringExtra("restoid");

        BackgroundWorker4 backgroundWorker = new BackgroundWorker4(this);
        backgroundWorker.execute();
//        ArrayList<OrdersModel> list = backgroundWorker.getOrders(customerid, restoid, orderid);


//        binding = ActivityOrderBinding.inflate(getLayoutInflater());
//        setContentView(binding.getRoot());
//        adapter =  new OrdersAdapter(list, this);
//        binding.ordersRecyclerView.setAdapter(adapter);
//
//        layoutManager = new LinearLayoutManager(this);
//        binding.ordersRecyclerView.setLayoutManager(layoutManager);





//        final Button btnordernow = (Button) findViewById(R.id.btnAddOrderNow);
//        btnordernow.setOnClickListener(new View.OnClickListener()
//        {
//            @Override
//            public void onClick(View v) {
//                Log.d("msg","yowlistening?");
//            }
//        });
///
//        btnordernow.setOnClickListener(new View.OnClickListener(){
//            @Override
//            public void onClick(View v) {
//                Log.d("msg","yowlistening?");
//            }
//        });

//        buttonOrdernow.setOnClickListener(new View.OnClickListener(){
//            @Override
//            public void onClick(View v) {
//                Log.d("msg","yowlistening?");
//                //Add to
//                Intent intent = new Intent(OrderActivity.this, OrderDetailActivity.class);
//                intent.putExtra("customerid",customerid);
//                intent.putExtra("restoid",restoid);
//                intent.putExtra("orderid",restoid);
//                intent.putExtra("totalprice",Double.toString(TotalPrice));
//                OrderActivity.this.startActivity(intent);
//            }
//        });

    }
    public String RandomGenerator()
    {
        int leftLimit = 97; // letter 'a'
        int rightLimit = 122; // letter 'z'
        int targetStringLength = 6;
        Random random = new Random();
        StringBuilder buffer = new StringBuilder(targetStringLength);
        for (int i = 0; i < targetStringLength; i++) {
            int randomLimitedInt = leftLimit + (int)
                    (random.nextFloat() * (rightLimit - leftLimit + 1));
            buffer.append((char) randomLimitedInt);
        }
        String generatedString = buffer.toString();

        System.out.println(generatedString);

        return generatedString;
    }
    public void Ordernow(View view)
    {
        Log.d("msg","yow order now listening?");
        orderid = RandomGenerator();

        Intent intent = new Intent(OrderActivity.this, OrderDetailActivity.class);
        intent.putExtra("customerid",customerid);
        intent.putExtra("restoid",restoid);
        intent.putExtra("orderid",orderid);
        intent.putExtra("totalprice",Integer.toString(TotalPrice));
        OrderActivity.this.startActivity(intent);
    }

    private void displayOrders(ArrayList<OrdersModel> list) {
        binding = ActivityOrderBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        adapter =  new OrdersAdapter(list, this);
        binding.ordersRecyclerView.setAdapter(adapter);

        layoutManager = new LinearLayoutManager(this);
        binding.ordersRecyclerView.setLayoutManager(layoutManager);

        for(OrdersModel orders : list )
        {
            TotalPrice += Integer.parseInt(orders.getPrice()) * Integer.parseInt(orders.getQty());
        }
//        glist = list;
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.orders_bar,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.nav_orders:
                Intent intent = new Intent(this, OrderActivity.class);
                intent.putExtra("restoid",restoid);
                intent.putExtra("customerid",customerid);
                this.startActivity(intent);
                break;

            case R.id.nav_restoid:
                Intent intent2 = new Intent(this, RestaurantActivity.class);
//                intent2.putExtra("restoid",restoid);
                intent2.putExtra("customerid",customerid);
                // intent.putExtra("orderid",customerid+restoid);
                this.startActivity(intent2);
                break;

            case R.id.nav_fooditems:
                Intent intent3 = new Intent(this, MainActivity.class );
                intent3.putExtra("restoid",restoid);
                intent3.putExtra("customerid",customerid);
                this.startActivity(intent3);
                break;

            case R.id.nav_orderstatus:
                Intent intent4 = new Intent(this,OrderDetailActivity.class);
//                intent4.putExtra("orderwaiting");
                this.startActivity(intent4);
        }
        return super.onOptionsItemSelected(item);
    }

    public class BackgroundWorker4 extends AsyncTask<String,Void,String> {

        OrderActivity parent;
        AlertDialog alertDialog;
        String DBAction = null;
        JSONObject jsonObj = null;
        //prepare item array for "A"
        JSONArray jsonArrayProducts = new JSONArray();
        String fooditem;
        String customer;
        ArrayList<OrdersModel> orderlist = new ArrayList<>();
        public BackgroundWorker4(OrderActivity parent)
        {
            this.parent = parent;
        }
        @Override
        protected String doInBackground(String... params) {

            String product_url ="http://140.118.115.141:80/shielaeats/mobilephp/getorders.php";
            try {
//
                URL url = new URL(product_url);
                HttpURLConnection httpURLConnection = (HttpURLConnection)url.openConnection();
                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.setDoOutput(true);
                httpURLConnection.setDoInput(true);
                OutputStream outputStream = httpURLConnection.getOutputStream();
                BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8"));
                String post_data = URLEncoder.encode("customerid","UTF-8")+"="+URLEncoder.encode(customerid,"UTF-8");
                bufferedWriter.write(post_data);
                bufferedWriter.flush();
                bufferedWriter.close();
                outputStream.close();
                InputStream inputStream = httpURLConnection.getInputStream();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream,"iso-8859-1"));
                String result="";
                String line="";
                while((line = bufferedReader.readLine())!= null) {
                    Log.d("Result PHP",line);
                    result += line;

                }

                bufferedReader.close();
                inputStream.close();
                httpURLConnection.disconnect();
                return result;
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }

            return null;
        }
//
//        @Override
//        protected void onPreExecute() {
//            alertDialog = new AlertDialog.Builder().create();
//            alertDialog.setTitle("Database Status");
//        }

        @Override
        protected void onPostExecute(String result) {
            if (result != "No Results") {
                System.out.println(result);
                String foodrestoid,foodid, fooddesc, foodname, foodqty, foodimage, foodprice, cartstatus;
//                ////                String string = "004-034556";
////                String[] parts = result.split("}");
////                System.out.println(Arrays.toString(parts));
                Pattern p = Pattern.compile("\\{([^}]*)\\}");
                Matcher m = p.matcher(result);
                while (m.find()) {
                    fooditem = "{"+m.group(1)+"}";
//                    fooditemslist.add(fooditem); //this adds an element to the list.
                    System.out.println(fooditem);

                    try {
                        jsonObj = new JSONObject(fooditem);
                        foodid = jsonObj.getString("FoodID");
                        foodname = jsonObj.getString("FoodName");
                        foodimage = jsonObj.getString("FoodImagePath");
                        foodprice = jsonObj.getString("FoodPrice");
                        fooddesc = jsonObj.getString("FoodDescription");
                        foodqty = jsonObj.getString("Quantity");
                        foodrestoid = jsonObj.getString("RestaurantID");
                        cartstatus = jsonObj.getString("CartStatus");
                        restoid = foodrestoid;
                        orderlist.add(new OrdersModel(foodimage,foodname,foodprice,fooddesc,customerid,foodrestoid,foodid,foodqty,cartstatus));
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
                parent.displayOrders(orderlist);
////                list = lista;
////                Log.d("List",list.toString());

            }


        }




    }
}