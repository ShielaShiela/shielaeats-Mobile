package com.example.shielaeats;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class CustomerActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer);


//        BottomNavigationView bottomNavigationView = (BottomNavigationView)findViewById(R.id.bottomView_Bar);
//        //BottomNavigationViewHelper.disableShiftMode(bottomNavigationView);
//
//        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
//            @Override
//            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
//                switch (item.getItemId()) {
//                    case R.id.nav_restaurants:
//                        Intent intent = new Intent(CustomerActivity.this, RestaurantActivity.class);
//                        startActivity(intent);
//                        break;
//
//                    case R.id.nav_orders:
//                        Intent intent2 = new Intent(CustomerActivity.this, OrderActivity.class);
//                        startActivity(intent2);
//                        break;
//
//
//                    case R.id.nav_search:
//                        break;
//                }
//                return false;
//            }
//        });
    }
}