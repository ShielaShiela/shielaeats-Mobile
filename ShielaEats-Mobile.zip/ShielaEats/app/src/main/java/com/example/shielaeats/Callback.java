package com.example.shielaeats;

import com.example.shielaeats.Models.MainModel;

import java.util.ArrayList;

public interface Callback {

    public void sendData(ArrayList<MainModel> list);
}
