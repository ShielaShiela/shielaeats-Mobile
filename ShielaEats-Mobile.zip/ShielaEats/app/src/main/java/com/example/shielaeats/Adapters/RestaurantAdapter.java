package com.example.shielaeats.Adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.shielaeats.MainActivity;
import com.example.shielaeats.Models.RestaurantModel;
import com.example.shielaeats.R;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class RestaurantAdapter extends RecyclerView.Adapter<RestaurantAdapter.viewholder>{

    ArrayList<RestaurantModel> list;
    Context context;

    public RestaurantAdapter(ArrayList<RestaurantModel> list, Context context){
        this.list = list;
        this.context = context;
    }
    @NonNull
    @Override
    public viewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.restaurant_sample, parent, false);

        return new viewholder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull viewholder holder, int position) {
        final RestaurantModel model = list.get(position);

        Picasso.get().load("http://140.118.115.141/shielaeats/resources/img/logo-white.png").into(holder.restoimage);
        //holder.restoimage.setImageResource(model.getRImage());
        holder.restoname.setText(model.getRName());
        holder.restoaddress.setText(model.getRAddress());
        holder.restocontactno.setText(model.getRContact());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(context, MainActivity.class);
                intent.putExtra("restoid",model.getRID());
                intent.putExtra("customerid",model.getCustomerid());
                context.startActivity(intent);
            }
        });


    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class viewholder extends RecyclerView.ViewHolder{

        ImageView restoimage;
        TextView restoname , restoaddress, restocontactno;

        public viewholder(@NonNull View itemView) {
            super(itemView);

            restoimage = itemView.findViewById(R.id.RestaurantImage);
            restoname = itemView.findViewById(R.id.restaurantName);
            restoaddress = itemView.findViewById(R.id.restaurantLocation);
            restocontactno = itemView.findViewById(R.id.restaurantContact);
        }
    }

}
