package com.example.shielaeats;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.shielaeats.Adapters.OrdersAdapter;
import com.example.shielaeats.Models.OrdersModel;
import com.example.shielaeats.databinding.ActivityUpdateBinding;
import com.squareup.picasso.Picasso;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;

public class UpdateActivity extends AppCompatActivity {

    ActivityUpdateBinding binding;
    OrdersAdapter adapter;
    LinearLayoutManager layoutManager;
    ArrayList<OrdersModel> list = new ArrayList<>();
    ImageView subtractimage,addimage;
    String foodimage;
    TextView quantity;
    String viewqty;
    int viewQty;
    String name, description,customerid,restoid,foodid,qty;
    int price, subprice;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update);

        binding = ActivityUpdateBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        final Button updatecart = (Button) findViewById(R.id.btnUpdate);
        quantity = (TextView) findViewById(R.id.quantity);


        price = Integer.parseInt(getIntent().getStringExtra("price"));
        name = getIntent().getStringExtra("name");
        description = getIntent().getStringExtra("desc");
        customerid = getIntent().getStringExtra("customerid");
        restoid = getIntent().getStringExtra("restaurantid");
        foodid = getIntent().getStringExtra("foodid");
        foodimage = getIntent().getStringExtra("image");
        String vQty = getIntent().getStringExtra("quantity");
        quantity.setText(vQty);

        subtractimage =(ImageView) findViewById(R.id.subtract);
        addimage = (ImageView) findViewById(R.id.add);

        String action = getIntent().getStringExtra("action");

        if (action.equals("delete"))
        {
            new AlertDialog.Builder(this)
                    .setTitle("Delete Item")
                    .setMessage("Are you sure to delete this item?")
                    .setPositiveButton("Yes", new DialogInterface.OnClickListener(){
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                            BackgroundWorker7 background = new BackgroundWorker7();
                            background.execute();

                        }
                    })
                    .setNegativeButton("No", new DialogInterface.OnClickListener(){
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                        }
                    }).show();
        }


        subtractimage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                viewqty = quantity.getText().toString();
                viewQty = Integer.parseInt(viewqty);
                viewQty = viewQty - 1;
                quantity.setText(Integer.toString(viewQty));
            }
        });

        addimage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                viewqty = quantity.getText().toString();
                viewQty = Integer.parseInt(viewqty);
                viewQty = viewQty + 1;
                quantity.setText(Integer.toString(viewQty));
            }
        });

        updatecart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //add to OrderList
                Log.d("Update ","Yow");
                subprice = Integer.parseInt(quantity.getText().toString()) * price;
                Toast.makeText(UpdateActivity.this,"Yow!",Toast.LENGTH_SHORT).show();
                BackgroundWorker6 backgroundWorker = new BackgroundWorker6();
                backgroundWorker.execute();
            }
        });

        Picasso.get().load(foodimage).into(binding.detailImage);
        binding.lblPrice.setText(String.format("%d",price));
        binding.lblFoodname.setText(name);
        binding.detailDescription.setText(description);

    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.orders_bar,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.nav_orders:
                Intent intent = new Intent(this, OrderActivity.class);
                intent.putExtra("restoid",restoid);
                intent.putExtra("customerid",customerid);
                this.startActivity(intent);
                break;

            case R.id.nav_restoid:
                Intent intent2 = new Intent(this, RestaurantActivity.class);
//                intent2.putExtra("restoid",restoid);
                intent2.putExtra("customerid",customerid);
                // intent.putExtra("orderid",customerid+restoid);
                this.startActivity(intent2);
                break;

            case R.id.nav_fooditems:
                Intent intent3 = new Intent(this, MainActivity.class );
                intent3.putExtra("restoid",restoid);
                intent3.putExtra("customerid",customerid);
                this.startActivity(intent3);
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    public class BackgroundWorker6 extends AsyncTask<String,ArrayList,String> {

        @Override
        protected String doInBackground(String... params) {

            String product_url = "http://140.118.115.141:80/shielaeats/mobilephp/updateCart.php";
            try {
                Log.d("FoodID:", foodid);
                String getrestaurants = "shielaeats";
                URL url = new URL(product_url);
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.setDoOutput(true);
                httpURLConnection.setDoInput(true);
                OutputStream outputStream = httpURLConnection.getOutputStream();
                BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8"));
                String post_data = URLEncoder.encode("customerid", "UTF-8") + "=" + URLEncoder.encode(customerid, "UTF-8") + "&"
                        + URLEncoder.encode("restaurantid", "UTF-8") + "=" + URLEncoder.encode(restoid, "UTF-8") + "&"
                        + URLEncoder.encode("foodid", "UTF-8") + "=" + URLEncoder.encode(foodid, "UTF-8") + "&"
                        + URLEncoder.encode("quantity", "UTF-8") + "=" + URLEncoder.encode(quantity.getText().toString(), "UTF-8");
                bufferedWriter.write(post_data);
                bufferedWriter.flush();
                bufferedWriter.close();
                outputStream.close();
                InputStream inputStream = httpURLConnection.getInputStream();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream, "iso-8859-1"));
                String result = "";
                String line = "";
                while ((line = bufferedReader.readLine()) != null) {
                    Log.d("Result PHP", line);
                    result += line;

                }

                bufferedReader.close();
                inputStream.close();
                httpURLConnection.disconnect();
                return result;
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }

            return null;
        }


        @Override
        protected void onPostExecute(String result) {
            Log.d("DB", result);
//            Toast.makeText(getApplicationContext(),result,Toast.LENGTH_SHORT).show();
//            alertDialog.setMessage(result);
            if (result.equals("Order Successfully Updated")) {
                Toast.makeText(getApplicationContext(), result, Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(UpdateActivity.this, OrderActivity.class);
                intent.putExtra("restoid", restoid);
                intent.putExtra("customerid", customerid);
                UpdateActivity.this.startActivity(intent);
            }

//             alertDialog.show();

        }
    }


    public class BackgroundWorker7 extends AsyncTask<String,ArrayList,String> {

        @Override
        protected String doInBackground(String... params) {

            String product_url = "http://140.118.115.141:80/shielaeats/mobilephp/deleteitem.php";
            try {
                Log.d("FoodID:", foodid);
                String getrestaurants = "shielaeats";
                URL url = new URL(product_url);
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.setDoOutput(true);
                httpURLConnection.setDoInput(true);
                OutputStream outputStream = httpURLConnection.getOutputStream();
                BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8"));
                String post_data = URLEncoder.encode("customerid", "UTF-8") + "=" + URLEncoder.encode(customerid, "UTF-8") + "&"
                        + URLEncoder.encode("restaurantid", "UTF-8") + "=" + URLEncoder.encode(restoid, "UTF-8") + "&"
                        + URLEncoder.encode("foodid", "UTF-8") + "=" + URLEncoder.encode(foodid, "UTF-8") + "&"
                        + URLEncoder.encode("quantity", "UTF-8") + "=" + URLEncoder.encode(quantity.getText().toString(), "UTF-8");
                bufferedWriter.write(post_data);
                bufferedWriter.flush();
                bufferedWriter.close();
                outputStream.close();
                InputStream inputStream = httpURLConnection.getInputStream();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream, "iso-8859-1"));
                String result = "";
                String line = "";
                while ((line = bufferedReader.readLine()) != null) {
                    Log.d("Result PHP", line);
                    result += line;

                }

                bufferedReader.close();
                inputStream.close();
                httpURLConnection.disconnect();
                return result;
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }

            return null;
        }


        @Override
        protected void onPostExecute(String result) {
            Log.d("DB", result);
//            Toast.makeText(getApplicationContext(),result,Toast.LENGTH_SHORT).show();
//            alertDialog.setMessage(result);
            if (result.equals("Order Deleted")) {
                Toast.makeText(UpdateActivity.this, result, Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(UpdateActivity.this, OrderActivity.class);
                intent.putExtra("restoid", restoid);
                intent.putExtra("customerid", customerid);
                UpdateActivity.this.startActivity(intent);
            }

//             alertDialog.show();

        }
    }
}