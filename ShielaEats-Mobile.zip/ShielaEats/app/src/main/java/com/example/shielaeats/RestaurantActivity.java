package com.example.shielaeats;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.shielaeats.Adapters.RestaurantAdapter;
import com.example.shielaeats.Models.RestaurantModel;
import com.example.shielaeats.databinding.ActivityRestaurantBinding;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RestaurantActivity extends AppCompatActivity {

    ActivityRestaurantBinding binding;
    ArrayList<RestaurantModel> list = new  ArrayList<>();
    RestaurantAdapter adapter;
    LinearLayoutManager layoutManager;
    String customerid;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        customerid = getIntent().getStringExtra("customerid");
        Toast.makeText(this,"Hello User: "+ customerid,Toast.LENGTH_SHORT).show();
        System.out.println(customerid);

        BackgroundWorker1 backgroundWorker = new BackgroundWorker1(this);
        backgroundWorker.execute();

        binding = ActivityRestaurantBinding.inflate((getLayoutInflater()));
        setContentView(binding.getRoot());
        adapter =  new RestaurantAdapter (list, this);
        binding.restaurantRecyclerView.setAdapter(adapter);

        layoutManager = new LinearLayoutManager (this);
        binding.restaurantRecyclerView.setLayoutManager(layoutManager);

    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.orders_bar,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.nav_orders:
                Intent intent = new Intent(RestaurantActivity.this, OrderActivity.class);
                item.setTitle(customerid);
                intent.putExtra("customerid",customerid);
                RestaurantActivity.this.startActivity(intent);
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onStart() {
        super.onStart();
        binding = ActivityRestaurantBinding.inflate((getLayoutInflater()));
        setContentView(binding.getRoot());
        adapter =  new RestaurantAdapter (list, this);
        binding.restaurantRecyclerView.setAdapter(adapter);

        layoutManager = new LinearLayoutManager (this);
        binding.restaurantRecyclerView.setLayoutManager(layoutManager);

    }

    public void displayRestaurants(ArrayList<RestaurantModel> list)
    {
        binding = ActivityRestaurantBinding.inflate((getLayoutInflater()));
        setContentView(binding.getRoot());
        adapter =  new RestaurantAdapter (list, this);
        binding.restaurantRecyclerView.setAdapter(adapter);

        layoutManager = new LinearLayoutManager (this);
        binding.restaurantRecyclerView.setLayoutManager(layoutManager);

    }
    public class BackgroundWorker1 extends AsyncTask<String,ArrayList,String> {

        RestaurantActivity parent;
        public BackgroundWorker1(RestaurantActivity parent)
        {
            this.parent = parent;
        }


        @Override
        protected String doInBackground(String... params) {
            String product_url ="http://140.118.115.141:80/shielaeats/mobilephp/getresto.php";
            try {
                String getrestaurants = "shielaeats";
                URL url = new URL(product_url);
                HttpURLConnection httpURLConnection = (HttpURLConnection)url.openConnection();
                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.setDoOutput(true);
                httpURLConnection.setDoInput(true);
                OutputStream outputStream = httpURLConnection.getOutputStream();
                BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8"));
                bufferedWriter.write(URLEncoder.encode("shielaeats","UTF-8")+"="+URLEncoder.encode(getrestaurants,"UTF-8"));
                bufferedWriter.flush();
                bufferedWriter.close();
                outputStream.close();
                InputStream inputStream = httpURLConnection.getInputStream();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream,"iso-8859-1"));
                String result="";
                String line="";
                while((line = bufferedReader.readLine())!= null) {
                    Log.d("List of Restaurants",line);
                    result += line;
                }
                bufferedReader.close();
                inputStream.close();
                httpURLConnection.disconnect();
                return result;
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }

            return null;
        }

        @Override
        protected void onPostExecute(String result) {
            if (result != "No Results") {
                String restoid, restoname, restolocation, restocontact, restoowner;
                JSONObject jsonObj = null;
                String restoitem;
                ArrayList<RestaurantModel> restaurants = new ArrayList<>();
                Pattern p = Pattern.compile("\\{([^}]*)\\}");
                Matcher m = p.matcher(result);

                while (m.find()) {
                    restoitem = "{"+m.group(1)+"}";
                    Log.d("Restaurant Info: ",restoitem);
                    try {
                        jsonObj = new JSONObject(restoitem);
                        restoid = jsonObj.getString("RestoID");
                        restoname = jsonObj.getString("RestoName");
                        restolocation = jsonObj.getString("RestoAddress");
                        restocontact = jsonObj.getString("RestoContactno");
                        restoowner = jsonObj.getString("RestoOwner");

                        restaurants.add(new RestaurantModel(restoid,restoname,restolocation,restocontact,customerid));
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
                parent.displayRestaurants(restaurants);

            }


        }




    }
}