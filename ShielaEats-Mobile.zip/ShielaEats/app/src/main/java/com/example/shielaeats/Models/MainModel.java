package com.example.shielaeats.Models;

public class MainModel {

    String image;
    int image1;
    String name, price, description,customerid,restaurantid,foodid,qty;

    public MainModel(String image, String name, String price, String description,String customer, String resto,String foodid) {
        this.image = image;
        this.name = name;
        this.price = price;
        this.description = description;
        this.customerid = customer;
        this.restaurantid = resto;
        this.foodid = foodid;
    }
    public MainModel(String image, String name, String price, String description,String customer, String resto,String foodid,String qty) {
        this.image = image;
        this.name = name;
        this.price = price;
        this.description = description;
        this.customerid = customer;
        this.restaurantid = resto;
        this.foodid = foodid;
        this.qty = qty;
    }

    public String getQty() {
        return qty;
    }

    public void setQty(String qty) {
        this.qty = qty;
    }

    public String getFoodid() {
        return foodid;
    }

    public void setFoodid(String foodid) {
        this.foodid = foodid;
    }

    public String getRestaurantid() {
        return restaurantid;
    }

    public void setRestaurantid(String restaurantid) {
        this.restaurantid = restaurantid;
    }

    public String getCustomerid() {
        return customerid;
    }

    public void setCustomerid(String customerid) {
        this.customerid = customerid;
    }

    public MainModel(int image, String name, String price, String description, String customerid, String restoid) {
        this.image1 = image;
        this.name = name;
        this.price = price;
        this.description = description;
        this.customerid = customerid;
        this.restaurantid = restoid;
    }

    public int getImage1() {
        return image1;
    }

    public void setImage1(int image1) {
        this.image1 = image1;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
