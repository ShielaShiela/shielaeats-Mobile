package com.example.shielaeats;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.shielaeats.Models.OrdersModel;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;

public class OrderDetailActivity extends AppCompatActivity {


    TextView totalpricetxt;
    EditText customername, customeraddress, customermobile;
    Spinner customerpayment;
    String customerid, restoid, orderid, totalprice,name,address,mobile,payment;
    TextView lbldeliverystatus;
    TextView lblorderid;
    TextView txtdeliverystatus;
    Button confirmorder;
    int checkstatus = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_detail);

        customerid = getIntent().getStringExtra("customerid");
        restoid = getIntent().getStringExtra("restoid");
        orderid = getIntent().getStringExtra("orderid");
        totalprice = getIntent().getStringExtra("totalprice");

        customerpayment = (Spinner) findViewById(R.id.customerPaymentType);
        customername = (EditText) findViewById(R.id.editCustomername);
        customeraddress = (EditText) findViewById(R.id.editAddress);
        customermobile = (EditText) findViewById(R.id.editContactno);
        totalpricetxt = (TextView) findViewById(R.id.txtTotalprice);
        totalpricetxt.setText(totalprice);

//

//        Log.d("My Precious", totalprice);

        ArrayAdapter<String> myAdapter = new ArrayAdapter<String>(OrderDetailActivity.this,
                android.R.layout.simple_list_item_1, getResources().getStringArray(R.array.paymentoptions));
        myAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        customerpayment.setAdapter(myAdapter);

//

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.orders_bar,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){

            case R.id.nav_orderstatus:
                Intent intent4 = new Intent(this,OrderDetailActivity.class);
                intent4.putExtra("restoid",restoid);
                intent4.putExtra("customerid",customerid);
                intent4.putExtra("orderid",orderid);
                intent4.putExtra("totalprice",totalprice);
                this.startActivity(intent4);
        }
        return super.onOptionsItemSelected(item);
    }

    public void getOrderStatus()
    {
        String orderdeliverystatus;

        BackgroundWorker9 background = new BackgroundWorker9(this);
        background.execute();

    }

    public String deliverystatus(String status)
    {
        lbldeliverystatus = (TextView) findViewById(R.id.lblDeliveryStatus);
        lblorderid = (TextView) findViewById(R.id.lblOrderid);
        txtdeliverystatus = (TextView) findViewById(R.id.txtDeliveryStatus);
        confirmorder = (Button) findViewById(R.id.btnConfirmOrder);

        txtdeliverystatus.setText(status);

        if(status.equals("Delivered"))
        {
            String stat = txtdeliverystatus.getText().toString();
//            if (stat.equals(status)) {
//                try {
//                    Thread.sleep(5000);
//
//                } catch (Exception e) {
//                    e.printStackTrace();
//                }
//            }

            confirmorder.setText("CONFIRM ORDER");
            lbldeliverystatus.setVisibility(View.GONE);
            lblorderid.setVisibility(View.GONE);
            txtdeliverystatus.setVisibility(View.GONE);

            customername.setEnabled(Boolean.TRUE);
            customeraddress.setEnabled(Boolean.TRUE);
            customermobile.setEnabled(Boolean.TRUE);
            customerpayment.setEnabled(Boolean.TRUE);
            BackgroundWorker10 background = new BackgroundWorker10(this);
            background.execute();

        }
        return status;
    }

    public void OrderSent()
    {
        lbldeliverystatus = (TextView) findViewById(R.id.lblDeliveryStatus);
        lblorderid = (TextView) findViewById(R.id.lblOrderid);
        txtdeliverystatus = (TextView) findViewById(R.id.txtDeliveryStatus);
        confirmorder = (Button) findViewById(R.id.btnConfirmOrder);

        confirmorder.setText("Check Delivery");
        lbldeliverystatus.setVisibility(View.VISIBLE);
        lblorderid.setVisibility(View.VISIBLE);
        txtdeliverystatus.setVisibility(View.VISIBLE);

        lblorderid.setText(orderid);
        customername.setEnabled(Boolean.FALSE);
        customeraddress.setEnabled(Boolean.FALSE);
        customermobile.setEnabled(Boolean.FALSE);
//        confirmorder.setEnabled(Boolean.FALSE);
        customerpayment.setEnabled(Boolean.FALSE);

        //Set OrderList to Blank Update All to Cart Status to 0
        BackgroundWorker8 background = new BackgroundWorker8();
        background.execute();

//        getOrderStatus();

    }

    public void ConfirmOrder(View view)
    {
        if(checkstatus==0)
        {
            checkstatus = 1;
            payment = customerpayment.getSelectedItem().toString();
            name = customername.getText().toString();
            address = customeraddress.getText().toString();
            mobile = customermobile.getText().toString();

            System.out.println(orderid+customerid+restoid+name+address+mobile+payment+totalprice);
            BackgroundWorker5 backgroundWorker = new BackgroundWorker5(this);
            backgroundWorker.execute();
        }
        else
            {
                getOrderStatus();
            }


    }

    public class BackgroundWorker5 extends AsyncTask<String, ArrayList,String> {
        String customer;
        OrderDetailActivity parent;
        AlertDialog alertDialog;

        public BackgroundWorker5(OrderDetailActivity parent) {
            this.parent = parent;
        }

        @Override
        protected String doInBackground(String... params) {
            String payid;
            if (payment.equals("Cash on Delivery"))
            {
                payid = "0";
            }
            else
            {
                payid = "1";
            }
            String orderstatus = "5";
            String courierid = "0";
            String product_url ="http://140.118.115.141:80/shielaeats/mobilephp/addCustomerOrder.php";
            try {
                String getrestaurants = "shielaeats";
                URL url = new URL(product_url);
                HttpURLConnection httpURLConnection = (HttpURLConnection)url.openConnection();
                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.setDoOutput(true);
                httpURLConnection.setDoInput(true);
                OutputStream outputStream = httpURLConnection.getOutputStream();
                BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8"));
                String post_data = URLEncoder.encode("orderid","UTF-8")+"="+URLEncoder.encode(orderid,"UTF-8")+"&"
                        +URLEncoder.encode("customerid","UTF-8")+"="+URLEncoder.encode(customerid,"UTF-8")+"&"
                        +URLEncoder.encode("restaurantid","UTF-8")+"="+URLEncoder.encode(restoid,"UTF-8")+"&"
                        +URLEncoder.encode("customername","UTF-8")+"="+URLEncoder.encode(name,"UTF-8")+"&"
                        +URLEncoder.encode("customeraddress","UTF-8")+"="+URLEncoder.encode(address,"UTF-8")+"&"
                        +URLEncoder.encode("customermobile","UTF-8")+"="+URLEncoder.encode(mobile,"UTF-8")+"&"
                        +URLEncoder.encode("paymentid","UTF-8")+"="+URLEncoder.encode(payid,"UTF-8")+"&"
                        +URLEncoder.encode("orderstatus","UTF-8")+"="+URLEncoder.encode(orderstatus,"UTF-8")+"&"
                        +URLEncoder.encode("courierid","UTF-8")+"="+URLEncoder.encode(courierid,"UTF-8")+"&"
                        +URLEncoder.encode("totalprice","UTF-8")+"="+URLEncoder.encode(totalprice,"UTF-8");

                bufferedWriter.write(post_data);
                bufferedWriter.flush();
                bufferedWriter.close();
                outputStream.close();
                InputStream inputStream = httpURLConnection.getInputStream();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream,"iso-8859-1"));
                String result="";
                String line="";
                while((line = bufferedReader.readLine())!= null) {
                    Log.d("Result PHP",line);
                    result += line;

                }

                bufferedReader.close();
                inputStream.close();
                httpURLConnection.disconnect();
                return result;
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }

            return null;
        }
        //
        @Override
        protected void onPreExecute() {
           // alertDialog = new AlertDialog.Builder(DetailActivity.this).create();
           // alertDialog.setTitle("Database Status");
        }

        @Override
        protected void onPostExecute(String result) {
            Log.d("DB",result);
//            Toast.makeText(getApplicationContext(),result,Toast.LENGTH_SHORT).show();
//            alertDialog.setMessage(result);
            if (result.equals("Order Sent Successfully Added")) {
                parent.OrderSent();
                Log.d("DB result","YEY");
//                Intent intent = new Intent(DetailActivity.this,OrderActivity.class);
//                intent.putExtra("restoid",restoid);
//                intent.putExtra("customerid",customerid);
//                intent.putExtra("orderid",orderid);
//                DetailActivity.this.startActivity(intent);
            }

//             alertDialog.show();

        }

    }

    public class BackgroundWorker8 extends AsyncTask<String, ArrayList,String> {
        @Override
        protected String doInBackground(String... params) {

            String product_url = "http://140.118.115.141:80/shielaeats/mobilephp/updateOrderList.php";
            try {
//                Log.d("FoodID:", foodid);
                String getrestaurants = "shielaeats";
                URL url = new URL(product_url);
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.setDoOutput(true);
                httpURLConnection.setDoInput(true);
                OutputStream outputStream = httpURLConnection.getOutputStream();
                BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8"));
                String post_data = URLEncoder.encode("customerid", "UTF-8") + "=" + URLEncoder.encode(customerid, "UTF-8") + "&"
                        + URLEncoder.encode("restaurantid", "UTF-8") + "=" + URLEncoder.encode(restoid, "UTF-8");
                bufferedWriter.write(post_data);
                bufferedWriter.flush();
                bufferedWriter.close();
                outputStream.close();
                InputStream inputStream = httpURLConnection.getInputStream();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream, "iso-8859-1"));
                String result = "";
                String line = "";
                while ((line = bufferedReader.readLine()) != null) {
                    Log.d("Result PHP", line);
                    result += line;

                }

                bufferedReader.close();
                inputStream.close();
                httpURLConnection.disconnect();
                return result;
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }

            return null;
        }


        @Override
        protected void onPostExecute(String result) {
            Log.d("DB", result);
//            Toast.makeText(getApplicationContext(),result,Toast.LENGTH_SHORT).show();
//            alertDialog.setMessage(result);
//            if (result.equals("Cart Updated")) {
//                Toast.makeText(getApplicationContext(), result, Toast.LENGTH_SHORT).show();
////                Intent intent = new Intent(UpdateActivity.this, OrderActivity.class);
////                intent.putExtra("restoid", restoid);
////                intent.putExtra("customerid", customerid);
////                UpdateActivity.this.startActivity(intent);
//            }

//             alertDialog.show();

        }
    }

    public class BackgroundWorker9 extends AsyncTask<String, ArrayList,String> {
        OrderDetailActivity parent;
        AlertDialog alertDialog;
        String DBAction = null;
        JSONObject jsonObj = null;
        //prepare item array for "A"
        JSONArray jsonArrayProducts = new JSONArray();
        String fooditem;
        String customer;
        ArrayList<OrdersModel> orderlist = new ArrayList<>();

        public BackgroundWorker9(OrderDetailActivity parent) {
            this.parent = parent;
        }

        @Override
        protected String doInBackground(String... params) {

            String product_url = "http://140.118.115.141:80/shielaeats/mobilephp/getDeliverystatus.php";
            try {
                Log.d("OrderID",orderid);
//
                URL url = new URL(product_url);
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.setDoOutput(true);
                httpURLConnection.setDoInput(true);
                OutputStream outputStream = httpURLConnection.getOutputStream();
                BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8"));
                String post_data = URLEncoder.encode("customerid", "UTF-8") + "=" + URLEncoder.encode(customerid, "UTF-8")+"&"
                                  +URLEncoder.encode("orderid", "UTF-8") + "=" + URLEncoder.encode(orderid, "UTF-8");
                bufferedWriter.write(post_data);
                bufferedWriter.flush();
                bufferedWriter.close();
                outputStream.close();
                InputStream inputStream = httpURLConnection.getInputStream();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream, "iso-8859-1"));
                String result = "";
                String line = "";
                while ((line = bufferedReader.readLine()) != null) {
                    Log.d("Result PHP", line);
                    result += line;

                }

                bufferedReader.close();
                inputStream.close();
                httpURLConnection.disconnect();
                return result;
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }

            return null;
        }
//
//        @Override
//        protected void onPreExecute() {
//            alertDialog = new AlertDialog.Builder().create();
//            alertDialog.setTitle("Database Status");
//        }

        @Override
        protected void onPostExecute(String result) {
            if (result != "No Results") {
                parent.deliverystatus(result);
            }


        }
    }

    public class BackgroundWorker10 extends AsyncTask<String, ArrayList,String> {
        OrderDetailActivity parent;
        AlertDialog alertDialog;
        String DBAction = null;
        JSONObject jsonObj = null;
        //prepare item array for "A"
        JSONArray jsonArrayProducts = new JSONArray();
        String fooditem;
        String customer;
        ArrayList<OrdersModel> orderlist = new ArrayList<>();

        public BackgroundWorker10(OrderDetailActivity parent) {
            this.parent = parent;
        }

        @Override
        protected String doInBackground(String... params) {

            String product_url = "http://140.118.115.141:80/shielaeats/mobilephp/emptyCart.php";
            try {
                Log.d("OrderID",orderid);
//
                URL url = new URL(product_url);
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.setDoOutput(true);
                httpURLConnection.setDoInput(true);
                OutputStream outputStream = httpURLConnection.getOutputStream();
                BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8"));
                String post_data = URLEncoder.encode("customerid", "UTF-8") + "=" + URLEncoder.encode(customerid, "UTF-8")+"&"
                        +URLEncoder.encode("restoid", "UTF-8") + "=" + URLEncoder.encode(restoid, "UTF-8")+"&"
                        +URLEncoder.encode("orderid", "UTF-8") + "=" + URLEncoder.encode(orderid, "UTF-8");
                bufferedWriter.write(post_data);
                bufferedWriter.flush();
                bufferedWriter.close();
                outputStream.close();
                InputStream inputStream = httpURLConnection.getInputStream();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream, "iso-8859-1"));
                String result = "";
                String line = "";
                while ((line = bufferedReader.readLine()) != null) {
                    Log.d("Result PHP", line);
                    result += line;

                }

                bufferedReader.close();
                inputStream.close();
                httpURLConnection.disconnect();
                return result;
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }

            return null;
        }
//
//        @Override
//        protected void onPreExecute() {
//            alertDialog = new AlertDialog.Builder().create();
//            alertDialog.setTitle("Database Status");
//        }

        @Override
        protected void onPostExecute(String result) {
            if (result != "Failure to Update Cart") {
//                parent.deliverystatus(result);
                Intent intent = new Intent(OrderDetailActivity.this, RestaurantActivity.class);
                intent.putExtra("customerid", customerid);
                OrderDetailActivity.this.startActivity(intent);
            }


        }
    }
}