package com.example.shielaeats.Models;

public class RestaurantModel {

    int RImage;
    String RID, RName, RAddress,RContact, customerid;

    public RestaurantModel(String ID, String name, String location, String contact, String customerid) {
       // this.RImage = image;
        this.RName = name;
        this.RAddress = location;
        this.RContact = contact;
        this.RID = ID;
        this.customerid = customerid;
    }

    public String getCustomerid() {
        return customerid;
    }

    public void setCustomerid(String customerid) {
        this.customerid = customerid;
    }

    public String getRID() {
        return RID;
    }

    public void setRID(String RID) {
        this.RID = RID;
    }

    public int getRImage() {
        return RImage;
    }

    public void setRImage(int RImage) {
        this.RImage = RImage;
    }

    public String getRName() {
        return RName;
    }

    public void setRName(String RName) {
        this.RName = RName;
    }

    public String getRAddress() {
        return RAddress;
    }

    public void setRAddress(String RAddress) {
        this.RAddress = RAddress;
    }

    public String getRContact() {
        return RContact;
    }

    public void setRContact(String RContact) {
        this.RContact = RContact;
    }
}
