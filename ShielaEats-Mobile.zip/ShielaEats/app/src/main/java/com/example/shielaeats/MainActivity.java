package com.example.shielaeats;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.shielaeats.Adapters.MainAdapter;
import com.example.shielaeats.Models.MainModel;
import com.example.shielaeats.databinding.ActivityMainBinding;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class MainActivity extends AppCompatActivity{

    ArrayList<MainModel> list = new  ArrayList<>();
    ActivityMainBinding binding;
    MainAdapter adapter;
    LinearLayoutManager layoutManager;
    String customerid, restoid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        restoid = getIntent().getStringExtra("restoid");
        customerid = getIntent().getStringExtra("customerid");

        BackgroundWorker2 backgroundWorker = new BackgroundWorker2(this);
        backgroundWorker.execute();

//        binding = ActivityMainBinding.inflate(getLayoutInflater());
//        setContentView(binding.getRoot());
//        adapter =  new MainAdapter(list, this);
//        binding.recylerview.setAdapter(adapter);
//
//        layoutManager = new LinearLayoutManager(this);
//        binding.recylerview.setLayoutManager(layoutManager);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.orders_bar,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.nav_orders:
            Intent intent = new Intent(this, OrderActivity.class);
//                intent.putExtra("restoid",restoid);
            intent.putExtra("customerid",customerid);
            this.startActivity(intent);
            break;

            case R.id.nav_restoid:
                Intent intent2 = new Intent(this, RestaurantActivity.class);
//                intent2.putExtra("restoid",restoid);
                intent2.putExtra("customerid",customerid);
                // intent.putExtra("orderid",customerid+restoid);
                this.startActivity(intent2);
                break;

            case R.id.nav_fooditems:
                Intent intent3 = new Intent(this, MainActivity.class );
                intent3.putExtra("restoid",restoid);
                intent3.putExtra("customerid",customerid);
                this.startActivity(intent3);
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    private void displayProducts(ArrayList<MainModel> list) {
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        adapter =  new MainAdapter(list, this);
        binding.recylerview.setAdapter(adapter);

        layoutManager = new LinearLayoutManager(this);
        binding.recylerview.setLayoutManager(layoutManager);
    }

    @Override
    protected void onStart() {
        super.onStart();
//        binding = ActivityMainBinding.inflate(getLayoutInflater());
//        setContentView(binding.getRoot());
//        adapter =  new MainAdapter(list, this);
//        binding.recylerview.setAdapter(adapter);
//
//        layoutManager = new LinearLayoutManager(this);
//        binding.recylerview.setLayoutManager(layoutManager);
    }

    public class BackgroundWorker2 extends AsyncTask<String,Void,String> {

        MainActivity parent;
        AlertDialog alertDialog;
        String DBAction = null;



        public BackgroundWorker2(MainActivity parent)
        {
            this.parent = parent;
        }


        @Override
        protected String doInBackground(String... params) {

        Log.d("RestaurantID",restoid);
            String product_url ="http://140.118.115.141:80/shielaeats/mobilephp/getfoodproducts.php";
            try {
//                String restoid = "5";
                URL url = new URL(product_url);
                HttpURLConnection httpURLConnection = (HttpURLConnection)url.openConnection();
                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.setDoOutput(true);
                httpURLConnection.setDoInput(true);
                OutputStream outputStream = httpURLConnection.getOutputStream();
                BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8"));
                String post_data = URLEncoder.encode("restoid","UTF-8")+"="+URLEncoder.encode(restoid,"UTF-8");
                bufferedWriter.write(post_data);
                bufferedWriter.flush();
                bufferedWriter.close();
                outputStream.close();
                InputStream inputStream = httpURLConnection.getInputStream();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream,"iso-8859-1"));
                String result="";
                String line="";
                while((line = bufferedReader.readLine())!= null) {
                    Log.d("Result PHP",line);
                    result += line;
                }

                bufferedReader.close();
                inputStream.close();
                httpURLConnection.disconnect();
                return result;
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }

            return null;
        }
//
//        @Override
//        protected void onPreExecute() {
//            alertDialog = new AlertDialog.Builder().create();
//            alertDialog.setTitle("Database Status");
//        }

        @Override
        protected void onPostExecute(String result) {
            Log.d("DB Feedback: ",result);
            if (result != "No Results") {
                JSONObject jsonObj = null;
                String fooditem;
                ArrayList<MainModel> fooditemslist = new ArrayList<>();
                String foodid, foodname, fooddescription, foodimage, foodprice, foodstatus;
                int image;

                Pattern p = Pattern.compile("\\{([^}]*)\\}");
                Matcher m = p.matcher(result);
                while (m.find()) {
                    fooditem = "{"+m.group(1)+"}";
                    System.out.println(fooditem);

                    try {
                        jsonObj = new JSONObject(fooditem);
                        foodid = jsonObj.getString("FoodID");
                        foodname = jsonObj.getString("FoodName");
                        fooddescription = jsonObj.getString("FoodDescription");
                        foodimage = jsonObj.getString("FoodImagePath");
                        foodprice = jsonObj.getString("FoodPrice");
                        foodstatus = jsonObj.getString("FA");
                        System.out.println(foodimage);

                        fooditemslist.add(new MainModel(foodimage,foodname,foodprice,fooddescription,customerid,restoid,foodid));
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
                parent.displayProducts(fooditemslist);
//
            }


        }

    }

}