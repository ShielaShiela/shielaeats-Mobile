package com.example.shielaeats;

import android.app.AlertDialog;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import androidx.appcompat.app.AppCompatActivity;

public class SignupActivity extends AppCompatActivity {

    Button button;
    EditText Username, Password;
    Spinner spinner;
    String Usertype;
    String server_url = "http://140.118.115.141:80/signup.php";
    AlertDialog.Builder builder;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        button = (Button) findViewById(R.id.btnSignup);
        Username = (EditText) findViewById(R.id.SUusername);
        Password = (EditText) findViewById(R.id.SUpassword);
        spinner = (Spinner) findViewById(R.id.SUusertype);

        ArrayAdapter<String> myAdapter = new ArrayAdapter<String>(SignupActivity.this,
                android.R.layout.simple_list_item_1, getResources().getStringArray(R.array.names));
        myAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(myAdapter);
//        Usertype = spinner.getSelectedItem().toString();
    }

    public void OnSignup(View view) {
        String username = Username.getText().toString();
        String password = Password.getText().toString();
        String usertype = spinner.getSelectedItem().toString();
        Log.d("UserType",usertype);
        String type = "signup";


        BackgroundWorker backgroundWorker = new BackgroundWorker(this);

        backgroundWorker.execute(type, username, password,usertype);
        Username.getText().clear();
        Password.getText().clear();
    }

}

